package fr.epita.services.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.security.auth.login.Configuration;

/**
 * loads data from file
 * 
 * @author Faisal
 *
 */

public class MCQ_Configuration {
	private Properties properties;
	private static MCQ_Configuration configure;
	
	private MCQ_Configuration()
	{
		this.properties=new Properties();
		String configureLocation = System.getProperty("conf.location","application.properties");
		
		try (InputStream IS = new FileInputStream(new File(configureLocation))) {
			properties.load(IS);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

public static MCQ_Configuration getInstance() {
	if(configure == null) {
		configure = new MCQ_Configuration();
		}
	return configure;
	}

	public String getConfigurationValue(String configKey) {
		return properties.getProperty(configKey);
	}
}