package fr.epita.questions.datamodel;

/** It  holds MCQ Choices
 *  
 * @author Faisal
 *
 */

public class MCQ_Choice {
	private int MCQ_ID;
	private String Choice;
	
	public MCQ_Choice(int MCQ_ID,String Choice)
	{
		this.MCQ_ID = MCQ_ID;
		this.Choice=Choice;
	}

	public int getMCQ_ID() {
		return MCQ_ID;
	}

	public void setMCQ_ID(int mCQ_ID) {
		MCQ_ID = mCQ_ID;
	}

	public String getChoice() {
		return Choice;
	}

	public void setChoice(String choice) {
		Choice = choice;
	}
	
	@Override
	public String toString() {
		return "MCQChoice [ MCQ_ID=" + MCQ_ID + " Choice=" + Choice + "]";
	}
}
