package fr.epita.questions.datamodel;
/**
 * It saves the Results 
 * @author Faisal
 *
 */

public class MCQ_Results {
	private String Actual_Answer;
	private String User_Answer;
	public Object getActual_Answer;
	
	public MCQ_Results(String Actual_Answer,String User_Answer)
	{
		this.Actual_Answer=Actual_Answer;
		this.User_Answer=User_Answer;
	}

	public String getActual_Answer() {
		return Actual_Answer;
	}

	public void setActual_Answer(String actual_Answer) {
		Actual_Answer = actual_Answer;
	}

	public String getUser_Answer() {
		return User_Answer;
	}

	public void setUser_Answer(String user_Answer) {
		User_Answer = user_Answer;
	}
	
	

}
