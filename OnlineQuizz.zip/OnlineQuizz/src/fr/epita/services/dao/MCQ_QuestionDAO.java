package fr.epita.services.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.directory.Attributes;
import javax.naming.spi.DirStateFactory.Result;
import javax.security.auth.login.Configuration;

import fr.epita.questions.datamodel.MCQ_Answer;
import fr.epita.questions.datamodel.MCQ_Choice;
import fr.epita.questions.datamodel.MCQ_Questions;
import fr.epita.questions.datamodel.MCQ_Results;

/**
 * To get data from database
 * 
 * @author Faisal
 *
 */

public class MCQ_QuestionDAO {
	public static final String selectQuestQuery = "SELECT * FROM MCQ_QUESTION";
	public static final String AnswersQuery = "SELECT ACTUAL_ANSWER,USER_ANSWER from MCQ_ANSWERS ";
	public static final String AnswerQuery = "UPDATE MCQ_ANSWERS SET USER_ANSWER =? WHERE Q_ID =?";
	public static final String SelectMCQQuery = "SELECT * FROM MCQ_CHOICES WHERE Q_ID=?";
	
	
	/**
	 * IT IS USED TO RETRIVE ALL THE QUESTIONS
	 * 
	 * @return List<Qustions>
	 */
	
	public List<MCQ_Questions> getQuestions()
	{
		List<MCQ_Questions> resultlist = new ArrayList<MCQ_Questions>();
		
		try(Connection connection = getConnection();
				PreparedStatement prepareStatement = connection.prepareStatement(selectQuestQuery);)
		{
			ResultSet result=prepareStatement.executeQuery();
			while (result.next()) {
				int id = result.getInt("Q_ID");
				String difficulty=result.getString("DIFFICULTY");
				String isMcq = result.getString("ISMCQ");
				String topics = result.getString("TOPICS");
				String quest = result.getString("QUESTION");
				
				MCQ_Questions currentQuestion = new MCQ_Questions(id,topics,quest,difficulty,isMcq);
				resultlist.add(currentQuestion);
			}
			result.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return resultlist;
	}
	
	/**
	 * To get user entered results and actual results
	 * 
	 * @return List<Results>
	 */
	
	public List<MCQ_Results> getMCQ_Answer()
	{
		List<MCQ_Results>resultsList = new ArrayList<>();
		
		try(Connection connection = getConnection())
		{
			PreparedStatement statement = connection.prepareStatement(AnswersQuery);
			ResultSet result = statement.executeQuery();
			while(result.next())
			{
				String actual_answer = result.getString("ACTUAL_ANSWER");
				String user_answer = result.getString("USER_ANSWER");
				
				MCQ_Results result1= new MCQ_Results(actual_answer,user_answer);
				resultsList.add(result1);
			}
			result.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return resultsList;
	}
	
	/**
	 * It adds the user entered answers to database
	 * 
	 * @param answer
	 *
	 */
	
	public void addAnswer(MCQ_Answer answer) {
		try (Connection connection = getConnection())
		{
			PreparedStatement statement = connection.prepareStatement(AnswerQuery);
			statement.setString(1,answer.getAnswer());
			statement.setInt(2, answer.getQuestion_id());
			statement.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * To get MCQ for given questions
	 * 
	 * @param question
	 * @return List<MCQ_Choice>
	 */
	public List<MCQ_Choice>getMCQs(MCQ_Questions question)
	{
		List<MCQ_Choice> mcqChoicesList = new ArrayList<>();
		try (Connection connection = getConnection())
		{
			PreparedStatement statement = connection.prepareStatement(SelectMCQQuery);
			
			statement.setInt(1,question.getQuestion_Id());
			ResultSet results = statement.executeQuery();
			
			while (results.next())
			{
				int id = results.getInt("MCQ_ID");
				String choice = results.getString("CHOICE");
				
				MCQ_Choice mcqChoice = new MCQ_Choice(id,choice);
				mcqChoicesList.add(mcqChoice);
			}
			results.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return mcqChoicesList;
	}
	/**
	 * To establish connection with database
	 *  @return
	 *  @throws SQLExceptions
	 */
	
	private Connection getConnection() throws SQLException {
		MCQ_Configuration configuration =MCQ_Configuration.getInstance();
		String jdbcurl = configuration.getConfigurationValue("jdbc.url");
		String user = configuration.getConfigurationValue("jdbc.user");
		String password = configuration.getConfigurationValue("jdbc.password");
		Connection connection = DriverManager.getConnection(jdbcurl,user,password);
		return connection;
		
	}
	}
