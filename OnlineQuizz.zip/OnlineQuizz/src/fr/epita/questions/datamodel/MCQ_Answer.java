package fr.epita.questions.datamodel;

/** 
 * It holds the result 
 * @author Faisal
 * 
 *
 */

public class MCQ_Answer {
	
	private int Question_id;
	private String Answer;
	
	public MCQ_Answer(int Question_id,String text)
	{
		this.Question_id = Question_id;
		this.Answer = text;
	}

	public int getQuestion_id() {
		return Question_id;
	}

	public void setQuestion_id(int question_id) {
		Question_id = question_id;
	}

	public String getAnswer() {
		return Answer;
	}

	public void setAnswer(String answer) {
		Answer = answer;
	}
	
	@Override 
	
	public String toString()
	{
		return "Answer [Question_id=" + Question_id + ";Answer=" + Answer + "]";
		
	}

}
