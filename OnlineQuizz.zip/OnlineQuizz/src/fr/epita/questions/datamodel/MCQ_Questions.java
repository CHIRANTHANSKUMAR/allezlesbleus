package fr.epita.questions.datamodel;
/**
 * It holds all the questions
 * @author Faisal
 *
 */
public class MCQ_Questions {
	private int Question_Id;
	private String Topics;
	private String Question;
	private String Difficulty;
	private String IsMcq;
	
	public MCQ_Questions(int Question_Id,String Topics,String Question,String Difficulty, String IsMcq )
	{
		this.Question_Id=Question_Id;
		this.Topics=Topics;
		this.Question=Question;
		this.Difficulty=Difficulty;
		this.IsMcq=IsMcq;
		
	}
	@Override
	public String toString() {
		return "Question [id=" +Question_Id+ ",Question="+Question+",topics="+Topics+",difficulty="+Difficulty+"]";
		
	}
	public int getQuestion_Id() {
		return Question_Id;
	}
	public void setQuestion_Id(int question_Id) {
		Question_Id = question_Id;
	}
	public String getTopics() {
		return Topics;
	}
	public void setTopics(String topics) {
		Topics = topics;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getDifficulty() {
		return Difficulty;
	}
	public void setDifficulty(String difficulty) {
		Difficulty = difficulty;
	}
	public String isIsMcq() {
		return IsMcq;
	}
	public void setIsMcq(String isMcq) {
		IsMcq = isMcq;
	}
	
}
