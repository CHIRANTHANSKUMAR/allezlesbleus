package fr.epita.questions.tester;


import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

import javax.naming.spi.DirStateFactory.Result;

import fr.epita.questions.datamodel.MCQ_Answer;
import fr.epita.questions.datamodel.MCQ_Choice;
import fr.epita.questions.datamodel.MCQ_Questions;
import fr.epita.questions.datamodel.MCQ_Results;
import fr.epita.services.dao.MCQ_QuestionDAO;

/**
 * Launcher of the Application where the execution begins
 * 
 * @author faisal
 *
 */

public class Tester {
	private MCQ_QuestionDAO dao;
	
	
	public Tester()
	{
		dao = new MCQ_QuestionDAO();
	}
	
	public static void main(String[] args)
	{
		Tester tester = new Tester();
		tester.display_Question();
	}

/** 
 * Its Displays Questions to User
 */
	

	@SuppressWarnings("resource")
	private void display_Question() {
		List<MCQ_Questions> questions =dao.getQuestions();
		Collections.shuffle(questions, new Random());
		
		for (MCQ_Questions quest : questions)
		{
			System.out.println(quest.getQuestion());
			fetchMCQs(quest);
			
			Scanner scanner = new Scanner(System.in);
			String ans = scanner.nextLine(); 
			MCQ_Answer answer = new MCQ_Answer(quest.getQuestion_Id(),ans);
			dao.addAnswer(answer);
		}
		
		vAnswer();
		}
	
	/**
	 * It verifies the correct answer and display the scores
	 */
	
	private void vAnswer() {
		List<MCQ_Results> results = dao.getMCQ_Answer();
		int points = 0;
		
		for (MCQ_Results result : results) {
		
		if(result.getUser_Answer()!= null &&
				result.getActual_Answer().trim().equalsIgnoreCase(result.getUser_Answer().trim()))
		{
			points +=10;
		}
		
		
		
		}
		System.out.println("Your Score is :" + points);
}

	/**
	 * It Checks whether the given ID has MCQs. if yes then it displays the MCQs
	 * 
	 *    @param quest
	 *    
	 */

	private void fetchMCQs(MCQ_Questions quest)
	{
		List<MCQ_Choice> mcqchoice = new ArrayList<>();
		
		if (quest.isIsMcq().equalsIgnoreCase("true")) {
			mcqchoice = dao.getMCQs(quest);
			
			for (MCQ_Choice mcqChoice : mcqchoice) {
				System.out.println(mcqChoice.getChoice());
			}
		}
	}
}
	
		
	
